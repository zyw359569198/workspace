package com.zyw.TmallGod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TmallGodApplication {

	public static void main(String[] args) {
		SpringApplication.run(TmallGodApplication.class, args);
	}
}
